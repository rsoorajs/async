#  Pyrogram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2017-2020 Dan <https://github.com/delivrance>
#
#  This file is part of Pyrogram.
#
#  Pyrogram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Pyrogram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Pyrogram.  If not, see <http://www.gnu.org/licenses/>.

from pyrogram.api.types import KeyboardButton as RawKeyboardButton
from pyrogram.api.types import KeyboardButtonRequestPhone, KeyboardButtonRequestGeoLocation

from ..object import Object


class KeyboardButton(Object):
    """One button of the reply keyboard.
    For simple text buttons String can be used instead of this object to specify text of the button.
    Optional fields are mutually exclusive.

    Parameters:
        text (``str``):
            Text of the button. If none of the optional fields are used, it will be sent as a message when
            the button is pressed.

        request_contact (``bool``, *optional*):
            If True, the user's phone number will be sent as a contact when the button is pressed.
            Available in private chats only.

        request_location (``bool``, *optional*):
            If True, the user's current location will be sent when the button is pressed.
            Available in private chats only.
    """

    def __init__(
        self,
        text: str,
        request_contact: bool = None,
        request_location: bool = None
    ):
        super().__init__()

        self.text = str(text)
        self.request_contact = request_contact
        self.request_location = request_location

    @staticmethod
    def read(o):
        if isinstance(o, RawKeyboardButton):
            return o.text

        if isinstance(o, KeyboardButtonRequestPhone):
            return KeyboardButton(
                text=o.text,
                request_contact=True
            )

        if isinstance(o, KeyboardButtonRequestGeoLocation):
            return KeyboardButton(
                text=o.text,
                request_location=True
            )

    def write(self):
        # TODO: Enforce optional args mutual exclusiveness

        if self.request_contact:
            return KeyboardButtonRequestPhone(text=self.text)
        elif self.request_location:
            return KeyboardButtonRequestGeoLocation(text=self.text)
        else:
            return RawKeyboardButton(text=self.text)
